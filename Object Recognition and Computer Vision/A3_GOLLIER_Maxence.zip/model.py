import torch
import torch.nn as nn
import torch.nn.functional as F

from torchvision.models import resnet50, ResNet50_Weights
from torchvision.models import resnet34, ResNet34_Weights
from torchvision.models import efficientnet_v2_s,EfficientNet_V2_S_Weights
from torchvision.models import resnet152,ResNet152_Weights
from torchvision.models import googlenet,GoogLeNet_Weights
from torchvision.models import inception_v3,Inception_V3_Weights


import torchvision.transforms as transforms

nclasses = 250

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 10, kernel_size=5)
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)
        self.conv3 = nn.Conv2d(20, 20, kernel_size=5)
        self.fc1 = nn.Linear(320, 50)
        self.fc2 = nn.Linear(50, nclasses)

    def forward(self, x):
        x = F.relu(F.max_pool2d(self.conv1(x), 2))
        x = F.relu(F.max_pool2d(self.conv2(x), 2))
        x = F.relu(F.max_pool2d(self.conv3(x), 2))
        x = x.view(-1, 320)
        x = F.relu(self.fc1(x))
        return self.fc2(x)
    
class ResNet50(nn.Module): ## 70% performance ! 
    def __init__(self,load=False,freeze=0):
        super(ResNet50, self).__init__()

        # Load model
        self.ResNet = resnet50(weights= ResNet50_Weights.IMAGENET1K_V2)
        self.ResNet.fc = nn.Linear(2048,nclasses)

        if load :
            self.load_state_dict(torch.load("experiment/model_best.pth"))
              
        # Freeze layers
        for i,child in enumerate(self.ResNet.children()):
            if i < freeze:
                for param in child.parameters():
                    param.requires_grad=False
            else : break

    def forward(self,x):
        return self.ResNet.forward(x)
    
class ResNet152(nn.Module):  
    def __init__(self,load=False,freeze=0):
        super(ResNet152, self).__init__()

        # Load model
        self.ResNet = resnet152(weights= ResNet152_Weights.IMAGENET1K_V2)
        self.ResNet.fc = nn.Linear(2048,nclasses)

        if load :
            self.load_state_dict(torch.load("experiment/model_9.pth"))
              
        # Freeze layers
        for i,child in enumerate(self.ResNet.children()):
            if i < freeze:
                for param in child.parameters():
                    param.requires_grad=False
            else : break

    def forward(self,x):
        return self.ResNet.forward(x)


class GoogleNet(nn.Module):
    def __init__(self):
        super(GoogleNet,self).__init__()
        self.LeNet = googlenet(weights = GoogLeNet_Weights.IMAGENET1K_V1)
        self.LeNet.fc = nn.Linear(1024,nclasses)
    def forward(self,x):
        return self.LeNet.forward(x)
    

class ResNet34(nn.Module): ## Poor performance ...
    def __init__(self):
        super(ResNet34, self).__init__()
        self.ResNet = resnet34(weights=ResNet34_Weights.IMAGENET1K_V1)
        self.ResNet.fc = nn.Linear(512, nclasses)
    def forward(self,x):
        return self.ResNet.forward(x)
    
class EffNet(nn.Module):
    def __init__(self):
        super(EffNet, self).__init__()
        self.effnet = efficientnet_v2_s(weights= EfficientNet_V2_S_Weights.IMAGENET1K_V1)
        self.effnet.classifier = nn.Sequential(
            nn.Dropout(p=0.2, inplace=True),
            nn.Linear(1280, nclasses),
        )
    def forward(self,x):
        return self.effnet(x)
    
class Inception(nn.Module):
    def __init__(self):
        super(Inception, self).__init__()
        self.inception = inception_v3(weights= Inception_V3_Weights.IMAGENET1K_V1)
        self.inception.fc = nn.Linear(2048,nclasses)
        
    def forward(self,x):
        return self.inception(x)