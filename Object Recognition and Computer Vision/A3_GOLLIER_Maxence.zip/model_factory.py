"""Python file to instantite the model and the transform that goes with it."""
from model import Net,ResNet50,ResNet34,EffNet,ResNet152,GoogleNet,Inception
from data import data_transforms,data_augment


class ModelFactory:
    def __init__(self, model_name: str,augment= False,freeze =0,load = False):
        self.model_name = model_name
        self.augment = augment
        self.freeze = freeze
        self.load = load
        self.model = self.init_model()
        self.transform = self.init_transform()

    def init_model(self):
        if self.model_name == "basic_cnn":
            return Net()
        elif self.model_name == "resnet50":
            return ResNet50(freeze=self.freeze,load=self.load)
        elif self.model_name == "resnet34":
            return ResNet34()
        elif self.model_name == "effnet":
            return EffNet()
        elif self.model_name == "resnet152":
            return ResNet152()
        elif self.model_name == "googlenet":
            return GoogleNet()
        elif self.model_name == "inception":
            return Inception()
        else:
            raise NotImplementedError("Model not implemented")

    def init_transform(self):
        if not self.augment:
            return data_transforms
        else:
            return data_augment

    def get_model(self):
        return self.model

    def get_transform(self):
        return self.transform

    def get_all(self):
        return self.model, self.transform
