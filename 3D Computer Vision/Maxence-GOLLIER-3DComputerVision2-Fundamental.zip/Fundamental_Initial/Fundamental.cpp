// Imagine++ project
// Project:  Fundamental
// Author:   Pascal Monasse

#include "./Imagine/Features.h"
#include <Imagine/Graphics.h>
#include <Imagine/LinAlg.h>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace Imagine;
using namespace std;

static const float BETA = 0.01f; // Probability of failure

struct Match {
    float x1, y1, x2, y2;
};

// Display SIFT points and fill vector of point correspondences
void algoSIFT(Image<Color,2> I1, Image<Color,2> I2,
              vector<Match>& matches) {
    // Find interest points
    SIFTDetector D;
    D.setFirstOctave(-1);
    Array<SIFTDetector::Feature> feats1 = D.run(I1);
    drawFeatures(feats1, Coords<2>(0,0));
    cout << "Im1: " << feats1.size() << flush;
    Array<SIFTDetector::Feature> feats2 = D.run(I2);
    drawFeatures(feats2, Coords<2>(I1.width(),0));
    cout << " Im2: " << feats2.size() << flush;

    const double MAX_DISTANCE = 100.0*100.0;
    for(size_t i=0; i < feats1.size(); i++) {
        SIFTDetector::Feature f1=feats1[i];
        for(size_t j=0; j < feats2.size(); j++) {
            double d = squaredDist(f1.desc, feats2[j].desc);
            if(d < MAX_DISTANCE) {
                Match m;
                m.x1 = f1.pos.x();
                m.y1 = f1.pos.y();
                m.x2 = feats2[j].pos.x();
                m.y2 = feats2[j].pos.y();
                matches.push_back(m);
            }
        }
    }
}

vector<Match> getSample(vector<Match> &matches,int k){

    // Randomly sample k elements from vector

    vector<Match> samples; samples.reserve(k);
    vector<int> randomIntegers; randomIntegers.reserve(k);

    while(samples.size()<k){
        int randomInt = rand()%matches.size();

        if (find(randomIntegers.begin(), randomIntegers.end(), randomInt) == randomIntegers.end()) {
            randomIntegers.push_back(randomInt);
            samples.push_back(matches[randomInt]);
        }
    }
    return samples;
}

FMatrix<float,3,3> eightPoint(vector<Match> &matches){

    // Implementation of the normalized eight points algorithm, matches.size() should be 8 or more.
    // If more than 8 points are provided, a least square problem is solved.

    const int n = matches.size();

    FMatrix<float,3,3> N(0.f);

    Matrix<float>A(n+1,9);
    A.fill(0.f);

    Vector<float> S1(9);
    Matrix<float> U1(9,9);
    Matrix<float> V1(n+1,n+1);

    FVector<float,3> S2;
    FMatrix<float,3,3> U2, V2;

    FMatrix<float,3,3> F;
    N(0,0) = 1e-3;
    N(1,1) = 1e-3;
    N(2,2) = 1.0;


    for(int i = 0;i<n;i++){
        Match match = matches[i];

        float x1 = 1e-3*match.x1; float x2 = 1e-3*match.x2 ;float y1 = 1e-3*match.y1; float y2 = 1e-3*match.y2;

        A(i,0) = x1*y1; A(i,1) = x1*y2; A(i,2) = x1;
        A(i,3) = x2*y1; A(i,4) = y1*y2; A(i,5) = y1;
        A(i,6) = x2; A(i,7) = y2; A(i,8) = 1.0;
    }

    svd(A,U1,S1,V1);

    for(int p = 0;p<3;p++){
        for(int q = 0;q<3;q++){
            F(p,q) = V1.getRow(8)[3*p+q];
        }
    }

    svd(F,U2,S2,V2);
    S2[2] = 0.f;

    F = N*U2*Diagonal(S2)*V2*N;

    return F;
}


float dist(Match &match ,FMatrix<float,3,3> &F){

    // Distance function from point y to epipolar line F^T x

    DoublePoint3 x; DoublePoint3 y;
    x[0] = match.x1; x[1] = match.y1; x[2] = 1.0;
    y[0] = match.x2; y[1] = match.y2; y[2] = 1.0;

    FVector<float,3> line = transpose(F)*x;

    float dist = abs(line[0]*y[0] + line[1]*y[1] + line[2]);
    float norm = sqrt(pow(line[0],2)+pow(line[1],2));

    return dist/norm;
}
// RANSAC algorithm to compute F from point matches (8-point algorithm)
// Parameter matches is filtered to keep only inliers as output.
FMatrix<float,3,3> computeF(vector<Match>& matches) {
    const float distMax = 1.5f; // Pixel error for inlier/outlier discrimination
    int Niter=100000; // Adjusted dynamically
    FMatrix<float,3,3> bestF;
    vector<int> bestInliers;

    int iter = 0;
    while(iter<Niter){
        iter ++;

        vector<Match> samples = getSample(matches,8);
        FMatrix<float,3,3> F = eightPoint(samples);
        vector<int> inliers;

        for(int j = 0;j<matches.size();j++){
            if(dist(matches[j],F)<distMax){
                inliers.push_back(j);
            }
        }

        if(inliers.size()>bestInliers.size()){
            bestInliers = inliers;
            bestF = F;
        }
        if(bestInliers.size()>50) // Avoid int overflow
            Niter = min(int(log(0.01)/log(1-pow(((float)bestInliers.size()/(float)matches.size()),8))),Niter);

    }

    // Fill matches with inliers
    vector<Match> temp =matches;
    matches.clear();
    for(int i=0; i<bestInliers.size(); i++)
        matches.push_back(temp[bestInliers[i]]);


    //perform least squares
    eightPoint(matches);

    return bestF;
}

// Expects clicks in one image and show corresponding line in other image.
// Stop at right-click.
void displayEpipolar(Image<Color> I1, Image<Color> I2,
                     const FMatrix<float,3,3>& F) {
    while(true) {
        int x,y;
        if(getMouse(x,y) == 3)
            break;
        FVector<float, 3> line;
        DoublePoint3 p;
        if(x>I1.width()){
            p[0] = x-I1.width(); p[1] = y;p[2] = 1.0;
            line = F*p;
            drawLine(0,(-1)*line[2]/line[1],I1.width(),(-1)*(line[2]+line[0]*I1.width())/line[1], RED);
        }
        else{
            p[0] = x; p[1] = y;p[2] = 1.0;
            line = transpose(F)*p;
            drawLine(I1.width(), (-1)*(line[2])/line[1], 2*I1.width(), (-1)*(line[2]+line[0]*I1.width())/line[1], RED);
        }
    }
}

int main(int argc, char* argv[])
{
    srand((unsigned int)time(0));

    const char* s1 = argc>1? argv[1]: srcPath("im1.jpg");
    const char* s2 = argc>2? argv[2]: srcPath("im2.jpg");

    // Load and display images
    Image<Color,2> I1, I2;
    if( ! load(I1, s1) ||
        ! load(I2, s2) ) {
        cerr<< "Unable to load images" << endl;
        return 1;
    }
    int w = I1.width();
    openWindow(2*w, I1.height());
    display(I1,0,0);
    display(I2,w,0);

    vector<Match> matches;
    algoSIFT(I1, I2, matches);
    const int n = (int)matches.size();
    cout << " matches: " << n << endl;
    drawString(100,20,std::to_string(n)+ " matches",RED);
    click();

    FMatrix<float,3,3> F = computeF(matches);
    cout << "F="<< endl << F;

    // Redisplay with matches
    display(I1,0,0);
    display(I2,w,0);
    for(size_t i=0; i<matches.size(); i++) {
        Color c(rand()%256,rand()%256,rand()%256);
        fillCircle(matches[i].x1+0, matches[i].y1, 2, c);
        fillCircle(matches[i].x2+w, matches[i].y2, 2, c);
    }
    drawString(100, 20, to_string(matches.size())+"/"+to_string(n)+" inliers", RED);
    click();

    // Redisplay without SIFT points
    display(I1,0,0);
    display(I2,w,0);
    displayEpipolar(I1, I2, F);

    endGraphics();
    return 0;
}
